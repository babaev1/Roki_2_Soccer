#include <roki2met.h>

void main(){
   sfBip(1, 1);
}